<?php 

/*

Plugin Name: Click Ad

Plugin URI: http://websharan.com/

Description: A Plugin to show Ads.

Version: 1.0

Author: Harmandeep Singh

Author URI: https://www.facebook.com/harmandeep.cheema2

License: GPL

*/

define( 'PLUGIN_DIR', dirname(__FILE__).'/' );

require_once( plugin_dir_path( __FILE__ ) . 'inc/main-table.php');

require_once( plugin_dir_path( __FILE__ ) . 'lib/display.php');

require_once( plugin_dir_path( __FILE__ ) . 'inc/menu-option.php');

require_once( plugin_dir_path( __FILE__ ) . '/lib/show-form.php');

require_once( plugin_dir_path( __FILE__ ) . '/lib/functions-file.php');

register_activation_hook( __FILE__, 'create_url_tb' );

