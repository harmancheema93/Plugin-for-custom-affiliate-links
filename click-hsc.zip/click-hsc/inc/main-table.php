<?php
function create_url_tb() {
	global $wpdb;
   $table_name = $wpdb->prefix . "url"; 
   global $wpdb;
$charset_collate = $wpdb->get_charset_collate();
 $sql = "CREATE TABLE $table_name (
  id mediumint(9) NOT NULL AUTO_INCREMENT,
  refrence_id text NOT NULL,    title text NOT NULL,
  url text NOT NULL,
  author_id text NOT NULL,
  author_name text NOT NULL,
  clicks text NOT NULL,
  clicked_by text NOT NULL,
  status ENUM('0' , '1') NOT NULL,
  inserted_on TIMESTAMP,
  PRIMARY KEY  (id)
) $charset_collate;";
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
add_option( 'jal_db_version', $jal_db_version );
}
?>