<?php
function user_reports()
{
	if ( ! is_super_admin() ) {
		return;
	}
	if ( ! isset( $_GET['user_report'] ) ) {
		return;
	}
	return false;
}
?>