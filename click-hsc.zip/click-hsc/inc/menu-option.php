<?php
/**
 * Register a custom menu page.
 */
function wpdocs_register_my_custom_menu_page_new(){
	 $PATH = site_url();
    add_menu_page( 
        __( 'Show Url', 'textdomain' ),
        'show Url',
        'manage_options',
        'url_added',
        'show_url_added'
		
    ); 
}
add_action( 'admin_menu', 'wpdocs_register_my_custom_menu_page_new' );
include( plugin_dir_path( __FILE__ ) . 'url_functions.php');
 ?>