<?php
/**
 * Display a custom menu page
 */
function show_url_added(){
		?>
		<?php include(plugin_dir_path( __FILE__ ) . '../lib/link.php');  ?>
		<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-2.0.3.js"></script>
		<link rel="stylesheet" href="files/simplePagination.css" />
		 
		<script src="<?php echo plugin_dir_url( __FILE__ ) . 'files/jquery.simplePagination.js' ; ?>"></script>
		<form method="POST"style="margin-top:10px;">		
		<Label for="title">Enter Title</label>		
		<input type="text" name="title" placeholder="Enter a Title"><br>
				<Label for="cred">Enter Points</label>		
		<input type="number" name="cred" placeholder="Enter Points"><br>
				<Label for="time">Enter Time</label>		
		<input type="text" name="time" placeholder="Enter a Time"><br>
		<Label for="url">Enter Url</label>		
		<input type="text" name="url" placeholder="Paste a url">		
		<button type="submit" class="btn-success" name="submit_url">SUBMIT</button>		
		</form>		
		<?php						 
		if ( 'POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['submit_url'])) {						 
		global $wpdb;						 
		$current_user = wp_get_current_user();						 
		$table_name = $wpdb -> prefix . 'url';						 
		$url = $_POST['url'];	$title = $_POST['title'];					 
		$author_name = $current_user -> user_login;						 
		$author_id = $current_user ->ID;						 
		$randNum = rand(1000,1000000000);  						 
		$refrence_id = dechex($randNum); 						 
		$query12 = "SELECT * from $table_name WHERE url = '$url'";						 
		$results12 = $wpdb->get_var($query12);												
		$wpdb->insert( 							
		$table_name, 							
		array( 							
		'refrence_id' => $refrence_id,  
		'title' => $title,		
		'author_id' => $author_id, 								
		'author_name' => $author_name,								
		'url' => $url,								
		'clicks' => 0,								
		'clicked_by' => $author_id,								
		'status' => '1'							   
		));						 
		echo 'Link Inserted';} ?>
		<?php 
		function custom_echo($x, $length)
{
  if(strlen($x)<=$length)
  {
    echo $x;
  }
  else
  {
    $y=substr($x,0,$length) . '...';
    echo $y;
  }
}
	global $wpdb;
	$limit = 50;  
	if (isset($_GET["count"])) { $page  = $_GET["count"];} else { $page=1; $i = 1; }  
	
	$start_from = ($page-1) * $limit; 
	if(isset($_GET['count']))
	{
	$i = $start_from +1;
	} 
	$table_name = $wpdb->prefix . "url";
	$query = "SELECT * FROM $table_name ORDER BY id DESC  LIMIT $start_from, $limit";
	 $results = $wpdb->get_results($query);
	?>
	<div class=""> 
	<form method="POST"  >
	<table  class="table table-striped">
		<tr>
		<th><input type="checkbox" name="select_all" id="select_all" value=""/><button name="hs-delete"onclick="return deleteConfirm();"><span class="glyphicon glyphicon-trash"></button><button name="hs-update-status"onclick="return deleteConfirm();" title="Status"><span class="glyphicon glyphicon-refresh"></button></th>
		<th>S NO.</th>
		<th>REF. ID</th>
		<th>Author ID</th>
		<th>Author NAME</th>
		<th>TITLE</th>
		<th>URL</th>
		<th>INSERTED ON</th>
		<th>CLICKS</th>
		<th>STATUS</th>
		<th>APPROVE</th>
		<th>REPORT</th>
		</tr>
		
		<?php
		 
		foreach ($results as $result) { ?>
		<tr>
		<td><input type="checkbox" name="checked_id[]" class="checkbox" value="<?php echo $result->id; ?> "/></td>
		<td><?= $i; ?> </td>
		<td><?= $result->refrence_id; ?> </td>
		<td><?= $result->author_id; ?> </td>
		<td><?= $result->author_name; ?> </td>
		<td><?= $result->title; ?> </td>
		<td style="width:60px"><a href="<?= $result->url; ?>" onclick="window.open('<?= $result->url; ?>', 'newwindow', 'width=900, height=500'); return false;"><?= $result->url; ?> </a></td>
		<td><?= $result->inserted_on; ?> </td>
		<td><?= $result->clicks; ?> </td>
		<td><?php if($result->status == 0){echo 'Unapproved';} else{echo 'Approved';} ?> </td>
		<td><?Php if($result->status == 0){?><button name="hs-update-status" class="  btn-danger"><span class="glyphicon glyphicon-thumbs-down"></button><?php } else { ?> <button name="hs-update-status" class=" btn-success"><span class="glyphicon glyphicon-thumbs-up"></button><?php } ?></form></td>
		<td><form action='<?php echo site_url(); ?>/report' target="_blank" method="GET"><input type="hidden" value='click' name='type'/><input type="hidden" value='<?php echo $result->refrence_id;?>' name='refid'/><button title="Download Report"><span class="glyphicon glyphicon-download-alt"></span></button></form></td>
		</tr><?php $i++; } ?>
		</table>
		</div>
		<?php   
			$site = site_url(); 
			$sql = "SELECT COUNT(id) FROM wp_url";  
			$rs_result = $wpdb->get_var($sql);  
			//$row = mysqli_fetch_row($rs_result);  
			$total_records = $rs_result;  
			$total_pages = ceil($total_records / $limit);  
			$pagLink = "<nav><ul class='pagination'>";  
			for ($i=1; $i<=$total_pages; $i++) {  
						 $pagLink .= "<li><a href='$site/wp-admin/admin.php?page=url_added&count=".$i."'>".$i."</a></li>";  
			};  
			echo $pagLink . "</ul></nav>";  
			?>
			</div>
			<div style="padding-bottom:50px;">
			<form method="GET" action="<?php echo esc_url( get_page_link( 4170 ) ); ?>" target="_blank">
			<label for="url">LINK</label>
			<input type="text" name="url" />
			<input type="hidden" name="type" value="click"/>
			<label for="from">FROM : </label>
			<input type="date" name="from" />
			<label for="to">TO : </label>
			<input type="date" name="to"  />
			<button>GENERATE</button>
			</form>
			</div>
			</body>
			</html>
		<?php
		if ( 'POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['hs-delete'])) {
		$idArr = $_POST['checked_id'];
		$site = site_url();
		foreach($idArr as $id){
		global $wpdb;
		$table_name = $wpdb->prefix . 'url';
		$query="DELETE from $table_name WHERE id = $id";
		 $results = $wpdb->get_results($query);
		}
		header("Location:$site/wp-admin/admin.php?page=url_added");
		}
		?>
		<?php if ( 'POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['hs-update-status'])) {
			$idArr = $_POST['checked_id'];
			$site = site_url();
			global $wpdb;
		$table_name = $wpdb->prefix . 'url';
		foreach($idArr as $id){
			echo $id;
			$query= "SELECT status from $table_name WHERE id = $id";
			echo $result = $wpdb->get_var($query);
		if ($result == 0){
		$query="UPDATE $table_name SET status = '1' WHERE id = $id";
		$results = $wpdb->get_results($query);}
		else
		{
		 $query="UPDATE $table_name SET status = '0' WHERE id = $id";
		$results = $wpdb->get_results($query);
		}
		}
		header("Location:$site/wp-admin/admin.php?page=url_added");
		}?>
		<script type="text/javascript">
function deleteConfirm(){
    var result = confirm("Are you sure?");
    if(result){
        return true;
    }else{
        return false;
    }
}

$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
});
</script>
	<script type="text/javascript">
			$(document).ready(function(){
			$('.pagination').pagination({
					items: <?php echo $total_records;?>,
					itemsOnPage: <?php echo $limit;?>,
					cssStyle: 'light-theme',
					currentPage : <?php echo $page;?>,
					hrefTextPrefix : '<?= $site ; ?>/wp-admin/admin.php?page=url_added&count='
				});
				});
			</script>
<?php } ?>