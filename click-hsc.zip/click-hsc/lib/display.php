<?php
function display_ad(){ ?>   <?php include(plugin_dir_path( __FILE__ ) . '../lib/link.php');  ?>
	<?php global $wpdb;
	$current_user = wp_get_current_user(); 
	$id = $current_user->ID;
	$table_name = $wpdb->prefix . 'url';
    $allowed_roles = array('editor', 'subscriber', 'author');
	if( array_intersect($allowed_roles, $current_user->roles ) ) {   
	   $cred = 5;
	 } else{
		 $cred = 20;
	 }
	$query="SELECT * from $table_name WHERE clicked_by NOT LIKE '%$id%' AND status != '0' AND author_id != '$current_user->ID' ORDER BY id DESC LIMIT 20  ";
	$results= $wpdb->get_results($query);
	$count = $wpdb->get_var($query);?>
	<?php if ($current_user->ID != 0){ ?>
	<?php
	if ($count != 0){?>
<script>
function myFunction() {
	setTimeout(function(){
		document.getElementById('click').removeAttribute('href');
		}, 1);
   setTimeout(function(){
    location.reload();
  },2900) 
}
</script>
	<form method="GET" ><table class="table table-striped table-responsive"><tr style="text-align:center;"><th>S No.</th><th>Title</th><th>Points</th></tr>
	<?php 	$i = 1;
	foreach ($results as $result) {?><tr><td><?= $i ?></td>
	<td><div><input type="hidden" name="ad" value="<?= $result->url;?>"><a href="<?= site_url()?>/frame?refid=<?=$result->refrence_id;?>" target="_blank" onclick="myFunction()">
	<?= $result->title;?></a>
	</div></td>	<td><?= $cred; ?></td></tr>
	<?php $i++;} ?>
	</table></form>
	<?php } else { 
	echo '<h5>No link found, try again after sometime......</h5>';
	}?>
	<?php }
	else{
		echo '<center><h1> You must login first</h1></center>';		
	}?>
<?php	} ?>
	<?php add_shortcode('show-Ad', 'display_ad');?>