<?php
function show_url_form()
{
?>
<?php if ( is_user_logged_in() ) { ?>
							<form method="POST">
							<label>Url</label>
							<input type="text" name="url" required>
							<button name="hs-url-btn">SUBMIT</button>
						  </form>
						 <?php } else { 
						 echo 'You Must Login First to insert link';
						 wp_login_form();
						 }
						 ?>
						 <?php
						 if ( 'POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['hs-url-btn'])) {
						 global $wpdb;
						 $current_user = wp_get_current_user();
						 $table_name = $wpdb -> prefix . 'url';
						 $url = $_POST['url'];
						 $author_name = $current_user -> user_login;
						 $author_id = $current_user ->ID;
						 $randNum = rand(1000,1000000000);  
						 $refrence_id = dechex($randNum); 
						 $query12 = "SELECT * from $table_name WHERE url = '$url'";
						 $results12 = $wpdb->get_var($query12);
						 if ($results12 == 0){
							$wpdb->insert( 
							$table_name, 
							array( 
							'refrence_id' => $refrence_id,
								'author_id' => $author_id, 
								'author_name' => $author_name,
								'url' => $url,
								'clicks' => 0,
								'clicked_by' => $author_id
							   ) 
						 );
						 echo 'Link Inserted';}
						else{
							echo 'Link Already Exist';
						}} ?>
<?php }?>

<?php
add_shortcode( 'show-url-form', 'show_url_form' );
?>